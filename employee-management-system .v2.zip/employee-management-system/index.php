<?php
require_once __DIR__ . '/includes/functions.php';

$ems_active_nav = 'dashboard';
$stats = ems_get_dashboard_stats();

include __DIR__ . '/includes/header.php';
?>

<div class="ems-page-title">Dashboard</div>
<div class="ems-page-subtitle">Operational overview &middot; refreshed on every page load</div>

<div class="ems-stat-grid">
  <div class="ems-stat">
    <div class="ems-stat-label">Employees</div>
    <div class="ems-stat-value">
      <?= $stats['total_employees'] !== null ? e((string)$stats['total_employees']) : '--' ?>
    </div>
    <div class="ems-stat-sub">Active records in database</div>
  </div>

  <div class="ems-stat">
    <div class="ems-stat-label">Departments</div>
    <div class="ems-stat-value">
      <?= $stats['total_departments'] !== null ? e((string)$stats['total_departments']) : '--' ?>
    </div>
    <div class="ems-stat-sub">Distinct departments in use</div>
  </div>

  <div class="ems-stat">
    <div class="ems-stat-label">Database</div>
    <div class="ems-stat-value">
      <span class="ems-dot <?= $stats['connected'] ? 'green' : 'red' ?>"></span>
      <span class="ems-status-text <?= $stats['connected'] ? 'green' : 'red' ?>">
        <?= $stats['connected'] ? 'CONNECTED' : 'UNAVAILABLE' ?>
      </span>
    </div>
    <div class="ems-stat-sub">RDS MySQL connection</div>
  </div>

  <div class="ems-stat">
    <div class="ems-stat-label">Application</div>
    <div class="ems-stat-value">
      <span class="ems-dot green"></span>
      <span class="ems-status-text green">RUNNING</span>
    </div>
    <div class="ems-stat-sub">PHP / Apache process</div>
  </div>
</div>

<div class="ems-panel">
  <div class="ems-panel-header">
    <h2>System Summary</h2>
  </div>
  <table class="ems-table">
    <tbody>
      <tr>
        <td style="width: 220px; color: var(--text-2);">Last Data Update</td>
        <td class="mono">
          <?= $stats['last_update'] ? e($stats['last_update']) : 'No records yet' ?>
        </td>
      </tr>
      <tr>
        <td style="color: var(--text-2);">Database Connection</td>
        <td>
          <span class="ems-dot <?= $stats['connected'] ? 'green' : 'red' ?>"></span>
          <span class="ems-status-text <?= $stats['connected'] ? 'green' : 'red' ?>">
            <?= $stats['connected'] ? 'CONNECTED' : 'CONNECTION FAILED' ?>
          </span>
        </td>
      </tr>
      <tr>
        <td style="color: var(--text-2);">Application Status</td>
        <td><span class="ems-dot green"></span> <span class="ems-status-text green">HEALTHY</span></td>
      </tr>
      <tr>
        <td style="color: var(--text-2);">Environment</td>
        <td class="mono"><?= e(ems_env('APP_ENV', 'local')) ?></td>
      </tr>
    </tbody>
  </table>
</div>

<?php if (!$stats['connected']): ?>
<div class="ems-panel">
  <div class="ems-panel-header"><h2>Notice</h2></div>
  <p style="color: var(--text-1); margin: 0;">
    The application cannot currently reach the database. Check that <span class="ems-badge">DB_HOST</span>,
    <span class="ems-badge">DB_NAME</span>, <span class="ems-badge">DB_USER</span>,
    <span class="ems-badge">DB_PASSWORD</span> and <span class="ems-badge">DB_PORT</span> are set correctly,
    and that the RDS security group allows inbound access from this EC2 instance.
    Visit <a href="<?= ems_link('health.php') ?>">System Status</a> for a detailed check.
  </p>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
