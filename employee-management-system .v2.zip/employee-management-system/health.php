<?php
/**
 * Health check endpoint.
 *
 * Used by the CloudSafe backup/restore pipeline to verify, after an
 * EC2 restore and/or RDS snapshot restore, that the application stack
 * is fully functional end to end.
 *
 * Supports two modes:
 *  - Browser view (default): a human-readable status page.
 *  - Machine mode (?format=json): a simple JSON payload for scripts,
 *    load balancer health checks, or CloudSafe automation.
 */

require_once __DIR__ . '/includes/functions.php';

$checks = [];

// 1. Web application / PHP is running (if this script executes, this is true).
$checks['app_running'] = true;
$checks['php_working'] = true;
$phpVersion = PHP_VERSION;

// 2 & 3. Can we connect to RDS, and does a simple query succeed?
$pdo = ems_get_connection();
$checks['db_connection'] = $pdo instanceof PDO;

$checks['db_query'] = false;
$employeeCount = null;
if ($pdo) {
    try {
        $row = $pdo->query('SELECT COUNT(*) AS c FROM employees')->fetch();
        $employeeCount = (int)$row['c'];
        $checks['db_query'] = true;
    } catch (PDOException $e) {
        error_log('[EMS] Health check query failed: ' . $e->getMessage());
        $checks['db_query'] = false;
    }
}

$overallHealthy = $checks['app_running'] && $checks['php_working'] && $checks['db_connection'] && $checks['db_query'];
$status = $overallHealthy ? 'HEALTHY' : 'UNHEALTHY';

// Machine-readable mode for automated CloudSafe validation scripts.
if (isset($_GET['format']) && $_GET['format'] === 'json') {
    header('Content-Type: application/json');
    http_response_code($overallHealthy ? 200 : 503);
    echo json_encode([
        'status'          => $status,
        'app_running'     => $checks['app_running'],
        'php_working'     => $checks['php_working'],
        'php_version'     => $phpVersion,
        'db_connection'   => $checks['db_connection'],
        'db_query'        => $checks['db_query'],
        'employee_count'  => $employeeCount,
        'timestamp'       => date('c'),
    ]);
    exit;
}

$ems_active_nav = 'status';
http_response_code($overallHealthy ? 200 : 503);
include __DIR__ . '/includes/header.php';
?>

<div class="ems-page-title">System Status</div>
<div class="ems-page-subtitle">Health check used for EC2 / RDS restore validation</div>

<div class="ems-panel">
  <div class="ems-panel-header"><h2>Checks</h2></div>
  <ul class="ems-health-list">
    <li>
      <span class="ems-dot <?= $checks['app_running'] ? 'green' : 'red' ?>"></span>
      Web application running &mdash;
      <span class="ems-status-text <?= $checks['app_running'] ? 'green' : 'red' ?>">
        <?= $checks['app_running'] ? 'OK' : 'FAIL' ?>
      </span>
    </li>
    <li>
      <span class="ems-dot <?= $checks['php_working'] ? 'green' : 'red' ?>"></span>
      PHP runtime (<?= e($phpVersion) ?>) &mdash;
      <span class="ems-status-text <?= $checks['php_working'] ? 'green' : 'red' ?>">
        <?= $checks['php_working'] ? 'OK' : 'FAIL' ?>
      </span>
    </li>
    <li>
      <span class="ems-dot <?= $checks['db_connection'] ? 'green' : 'red' ?>"></span>
      RDS MySQL connection &mdash;
      <span class="ems-status-text <?= $checks['db_connection'] ? 'green' : 'red' ?>">
        <?= $checks['db_connection'] ? 'OK' : 'FAIL' ?>
      </span>
    </li>
    <li>
      <span class="ems-dot <?= $checks['db_query'] ? 'green' : 'red' ?>"></span>
      Sample query (SELECT COUNT(*) FROM employees) &mdash;
      <span class="ems-status-text <?= $checks['db_query'] ? 'green' : 'red' ?>">
        <?= $checks['db_query'] ? 'OK' : 'FAIL' ?>
      </span>
      <?php if ($checks['db_query']): ?>
        <span class="ems-badge">count: <?= e((string)$employeeCount) ?></span>
      <?php endif; ?>
    </li>
  </ul>

  <div class="ems-health-final <?= $overallHealthy ? 'healthy' : 'unhealthy' ?>">
    <?= e($status) ?>
  </div>
</div>

<div class="ems-panel">
  <div class="ems-panel-header"><h2>Automation</h2></div>
  <p style="color: var(--text-1); margin: 0;">
    For scripted checks (CloudSafe restore validation), request
    <span class="ems-badge">/health.php?format=json</span>. It returns HTTP 200 with
    <span class="ems-badge">"status":"HEALTHY"</span> when all checks pass, or HTTP 503
    with <span class="ems-badge">"status":"UNHEALTHY"</span> otherwise. No credentials or
    internal error details are ever included in the response.
  </p>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
