-- ============================================================================
-- Employee Management System - Schema
-- Target: Amazon RDS for MySQL 8.0 (also works on local MySQL/MariaDB)
-- ============================================================================

CREATE DATABASE IF NOT EXISTS ems_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ems_db;

DROP TABLE IF EXISTS employees;

CREATE TABLE employees (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name         VARCHAR(100) NOT NULL,
  email        VARCHAR(150) NOT NULL,
  department   VARCHAR(60)  NOT NULL,
  salary       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_employees_email (email),
  KEY idx_employees_department (department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
