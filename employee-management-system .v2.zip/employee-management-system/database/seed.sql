-- ============================================================================
-- Employee Management System - Seed Data
-- Fictional employee records for CloudSafe backup/restore testing.
-- Run AFTER schema.sql.
-- ============================================================================

USE ems_db;

INSERT INTO employees (name, email, department, salary, created_at) VALUES
('Ahmed Hassan',        'ahmed.hassan@ems-corp.test',        'IT',             68000.00, '2025-01-10 09:15:00'),
('Omar El-Sayed',       'omar.elsayed@ems-corp.test',        'Cyber Security', 82000.00, '2025-01-12 10:20:00'),
('Ali Mostafa',         'ali.mostafa@ems-corp.test',         'Network',        61000.00, '2025-01-14 08:45:00'),
('Sara Ibrahim',        'sara.ibrahim@ems-corp.test',        'HR',             52000.00, '2025-01-15 11:00:00'),
('Mona Adel',           'mona.adel@ems-corp.test',           'Finance',        71000.00, '2025-01-16 13:30:00'),
('Youssef Karim',       'youssef.karim@ems-corp.test',       'IT',             65500.00, '2025-01-18 09:05:00'),
('Nour Fathy',          'nour.fathy@ems-corp.test',          'Cyber Security', 79000.00, '2025-01-20 14:10:00'),
('Khaled Mansour',      'khaled.mansour@ems-corp.test',      'Network',        59000.00, '2025-01-22 10:40:00'),
('Rana Samir',          'rana.samir@ems-corp.test',          'HR',             49500.00, '2025-01-25 09:50:00'),
('Tamer Zaki',          'tamer.zaki@ems-corp.test',          'Finance',        73500.00, '2025-01-27 15:00:00'),
('Dina Farouk',         'dina.farouk@ems-corp.test',         'IT',             67000.00, '2025-02-01 08:30:00'),
('Hassan Aboul-Fotouh',  'hassan.aboulfotouh@ems-corp.test',  'Cyber Security', 84500.00, '2025-02-03 09:20:00'),
('Laila Nabil',         'laila.nabil@ems-corp.test',         'Network',        60500.00, '2025-02-05 11:15:00'),
('Karim Shawky',        'karim.shawky@ems-corp.test',        'HR',             51000.00, '2025-02-07 12:45:00'),
('Yasmin Tarek',        'yasmin.tarek@ems-corp.test',        'Finance',        75000.00, '2025-02-10 10:00:00'),
('Mostafa Reda',        'mostafa.reda@ems-corp.test',        'IT',             62500.00, '2025-02-12 09:35:00'),
('Heba Gamal',          'heba.gamal@ems-corp.test',          'Cyber Security', 80500.00, '2025-02-15 13:20:00'),
('Amr Salah',           'amr.salah@ems-corp.test',           'Network',        58500.00, '2025-02-18 08:55:00'),
('Nadia Fouad',         'nadia.fouad@ems-corp.test',         'HR',             53500.00, '2025-02-20 14:40:00'),
('Sherif Aziz',         'sherif.aziz@ems-corp.test',         'Finance',        76500.00, '2025-02-22 09:10:00'),
('Fatma Wael',          'fatma.wael@ems-corp.test',          'IT',             64000.00, '2025-02-25 10:25:00'),
('Mahmoud Fahmy',       'mahmoud.fahmy@ems-corp.test',       'Cyber Security', 83000.00, '2025-02-27 11:50:00'),
('Salma Anwar',         'salma.anwar@ems-corp.test',         'Network',        59500.00, '2025-03-01 09:00:00'),
('Hany Sobhy',          'hany.sobhy@ems-corp.test',          'HR',             50500.00, '2025-03-03 13:05:00'),
('Iman Ragab',          'iman.ragab@ems-corp.test',          'Finance',        72500.00, '2025-03-05 15:30:00'),
('Waleed Kamal',        'waleed.kamal@ems-corp.test',        'IT',             66500.00, '2025-03-08 09:45:00'),
('Ghada Ashraf',        'ghada.ashraf@ems-corp.test',        'Cyber Security', 81500.00, '2025-03-10 10:10:00');
