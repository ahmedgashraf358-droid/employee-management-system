<?php
/**
 * Shared helper functions used across the Employee Management System.
 */

require_once __DIR__ . '/../config/database.php';

/** Escape a value for safe HTML output (prevents XSS). */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Basic trim + strip tags sanitizer for text input fields. */
function ems_clean(string $value): string
{
    return trim(strip_tags($value));
}

/**
 * Validates employee input. Returns an array of error messages.
 * Empty array means validation passed.
 */
function ems_validate_employee(array $data): array
{
    $errors = [];

    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $department = trim($data['department'] ?? '');
    $salary = $data['salary'] ?? '';

    if ($name === '' || strlen($name) > 100) {
        $errors[] = 'Name is required and must be under 100 characters.';
    }

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    }

    if ($department === '' || strlen($department) > 60) {
        $errors[] = 'Department is required and must be under 60 characters.';
    }

    if ($salary === '' || !is_numeric($salary) || (float)$salary < 0) {
        $errors[] = 'Salary is required and must be a positive number.';
    }

    return $errors;
}

/** Fixed list of departments used for the filter dropdown and add/edit forms. */
function ems_department_options(): array
{
    return ['IT', 'Cyber Security', 'Network', 'HR', 'Finance', 'Operations'];
}

/**
 * Fetch dashboard statistics. Returns null values when the DB is
 * unavailable so the dashboard can render a clear "unavailable" state.
 */
function ems_get_dashboard_stats(): array
{
    $pdo = ems_get_connection();

    $stats = [
        'connected'        => false,
        'total_employees'  => null,
        'total_departments' => null,
        'last_update'      => null,
    ];

    if (!$pdo) {
        return $stats;
    }

    try {
        $stats['connected'] = true;

        $stats['total_employees'] = (int)$pdo->query('SELECT COUNT(*) AS c FROM employees')->fetch()['c'];

        $stats['total_departments'] = (int)$pdo->query(
            'SELECT COUNT(DISTINCT department) AS c FROM employees'
        )->fetch()['c'];

        $lastUpdateRow = $pdo->query(
            'SELECT MAX(created_at) AS last_update FROM employees'
        )->fetch();
        $stats['last_update'] = $lastUpdateRow['last_update'] ?? null;
    } catch (PDOException $e) {
        error_log('[EMS] Failed to load dashboard stats: ' . $e->getMessage());
        $stats['connected'] = false;
    }

    return $stats;
}

/**
 * Fetch employees with optional search (name/email) and department filter.
 * Always uses prepared statements.
 */
function ems_get_employees(string $search = '', string $department = ''): array
{
    $pdo = ems_get_connection();
    if (!$pdo) {
        return [];
    }

    $sql = 'SELECT id, name, email, department, salary, created_at FROM employees WHERE 1=1';
    $params = [];

    if ($search !== '') {
        $sql .= ' AND (name LIKE :search_name OR email LIKE :search_email)';
        $params[':search_name'] = '%' . $search . '%';
        $params[':search_email'] = '%' . $search . '%';
    }

    if ($department !== '') {
        $sql .= ' AND department = :department';
        $params[':department'] = $department;
    }

    $sql .= ' ORDER BY id DESC';

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('[EMS] Failed to fetch employees: ' . $e->getMessage());
        return [];
    }
}

function ems_get_employee(int $id): ?array
{
    $pdo = ems_get_connection();
    if (!$pdo) {
        return null;
    }

    try {
        $stmt = $pdo->prepare('SELECT id, name, email, department, salary, created_at FROM employees WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    } catch (PDOException $e) {
        error_log('[EMS] Failed to fetch employee: ' . $e->getMessage());
        return null;
    }
}

function ems_create_employee(array $data): bool
{
    $pdo = ems_get_connection();
    if (!$pdo) {
        return false;
    }

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO employees (name, email, department, salary) VALUES (:name, :email, :department, :salary)'
        );
        return $stmt->execute([
            ':name'       => ems_clean($data['name']),
            ':email'      => ems_clean($data['email']),
            ':department' => ems_clean($data['department']),
            ':salary'     => (float)$data['salary'],
        ]);
    } catch (PDOException $e) {
        error_log('[EMS] Failed to create employee: ' . $e->getMessage());
        return false;
    }
}

function ems_update_employee(int $id, array $data): bool
{
    $pdo = ems_get_connection();
    if (!$pdo) {
        return false;
    }

    try {
        $stmt = $pdo->prepare(
            'UPDATE employees SET name = :name, email = :email, department = :department, salary = :salary WHERE id = :id'
        );
        return $stmt->execute([
            ':name'       => ems_clean($data['name']),
            ':email'      => ems_clean($data['email']),
            ':department' => ems_clean($data['department']),
            ':salary'     => (float)$data['salary'],
            ':id'         => $id,
        ]);
    } catch (PDOException $e) {
        error_log('[EMS] Failed to update employee: ' . $e->getMessage());
        return false;
    }
}

function ems_delete_employee(int $id): bool
{
    $pdo = ems_get_connection();
    if (!$pdo) {
        return false;
    }

    try {
        $stmt = $pdo->prepare('DELETE FROM employees WHERE id = :id');
        return $stmt->execute([':id' => $id]);
    } catch (PDOException $e) {
        error_log('[EMS] Failed to delete employee: ' . $e->getMessage());
        return false;
    }
}

/**
 * Resolves a path relative to the application root so links and asset
 * references work correctly whether the current script lives at the
 * root (index.php, health.php) or one level down (employees/*.php).
 */
function ems_base_path(): string
{
    // Path of the currently executing top-level script relative to the
    // document root, e.g. "/employees/create.php" or "/index.php".
    $scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php');
    return (basename($scriptDir) === 'employees') ? '../' : './';
}

function ems_link(string $path): string
{
    return ems_base_path() . $path;
}

function ems_asset_path(string $path): string
{
    return ems_base_path() . $path;
}

/** Simple flash-message helper using the session. */
function ems_set_flash(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['ems_flash'] = ['type' => $type, 'message' => $message];
}

function ems_get_flash(): ?array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (!empty($_SESSION['ems_flash'])) {
        $flash = $_SESSION['ems_flash'];
        unset($_SESSION['ems_flash']);
        return $flash;
    }
    return null;
}
