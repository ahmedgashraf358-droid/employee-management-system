<?php
// $ems_active_nav should be set by the including page: dashboard | employees | add | status
$ems_active_nav = $ems_active_nav ?? '';
$ems_db_ok = ems_db_is_connected();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EMS // Employee Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= ems_asset_path('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body>

<div class="ems-topbar">
  <div class="ems-identity">
    <span class="ems-tag">EMS //</span>
    <span class="ems-name">EMPLOYEE MANAGEMENT SYSTEM</span>
  </div>
  <div class="ems-system-status">
    <span class="ems-dot <?= $ems_db_ok ? 'green' : 'red' ?>"></span>
    SYSTEM <?= $ems_db_ok ? 'ONLINE' : 'DEGRADED' ?>
  </div>
</div>

<nav class="ems-nav">
  <ul>
    <li><a href="<?= ems_link('index.php') ?>" class="<?= $ems_active_nav === 'dashboard' ? 'active' : '' ?>">Dashboard</a></li>
    <li><a href="<?= ems_link('employees/index.php') ?>" class="<?= $ems_active_nav === 'employees' ? 'active' : '' ?>">Employees</a></li>
    <li><a href="<?= ems_link('employees/create.php') ?>" class="<?= $ems_active_nav === 'add' ? 'active' : '' ?>">Add Employee</a></li>
    <li><a href="<?= ems_link('health.php') ?>" class="<?= $ems_active_nav === 'status' ? 'active' : '' ?>">System Status</a></li>
  </ul>
</nav>

<div class="ems-container">
<?php
$flash = ems_get_flash();
if ($flash):
    $cls = $flash['type'] === 'error' ? 'ems-alert-error' : 'ems-alert-success';
?>
  <div class="ems-alert <?= $cls ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
