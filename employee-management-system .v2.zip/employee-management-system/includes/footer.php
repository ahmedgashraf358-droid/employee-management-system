</div><!-- /.ems-container -->

<div class="ems-footer">
  EMS-OPS &middot; Employee Management System &middot; CloudSafe Test Workload &middot; <?= e(date('Y-m-d H:i:s')) ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= ems_asset_path('assets/js/app.js') ?>"></script>
</body>
</html>
