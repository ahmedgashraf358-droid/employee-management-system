<?php
/**
 * Database configuration and connection handler.
 *
 * Credentials are NEVER hardcoded. They are read from environment
 * variables so the same codebase works locally, on EC2, and against
 * Amazon RDS for MySQL without any source changes.
 *
 * Required environment variables:
 *   DB_HOST      Hostname or RDS endpoint (e.g. ems-db.xxxxx.rds.amazonaws.com)
 *   DB_NAME      Database/schema name
 *   DB_USER      Database username
 *   DB_PASSWORD  Database password
 *   DB_PORT      Database port (default 3306)
 *
 * For local development, copy .env.example to .env and load it with
 * your shell (export $(cat .env | xargs)) or set the variables in your
 * Apache vhost / php-fpm pool configuration.
 */

// A tiny, dependency-free .env loader for local development convenience.
// On EC2 this is skipped in practice because real environment variables
// are exported by the OS / systemd unit, but it is harmless either way.
function ems_load_dotenv(string $path): void
{
    if (!is_readable($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (!str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value, " \t\n\r\0\x0B\"'");
        if (getenv($key) === false) {
            putenv("{$key}={$value}");
        }
    }
}

ems_load_dotenv(__DIR__ . '/../.env');

/**
 * Reads a configuration value from the environment, falling back to a
 * safe local-development default. Defaults are intentionally limited to
 * localhost values only — they must never be used against production.
 */
function ems_env(string $key, ?string $default = null): ?string
{
    $value = getenv($key);
    return ($value === false || $value === '') ? $default : $value;
}

/**
 * Returns a PDO connection to MySQL / Amazon RDS.
 *
 * On failure, returns null instead of throwing, so calling code
 * (dashboard, health check, CRUD pages) can degrade gracefully and show
 * a status message instead of a fatal PHP error / stack trace that
 * could leak connection details.
 */
function ems_get_connection(): ?PDO
{
    static $pdo = null;
    static $attempted = false;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    if ($attempted) {
        // Already tried and failed this request; don't retry repeatedly.
        return null;
    }
    $attempted = true;

    $host = ems_env('DB_HOST', '127.0.0.1');
    $port = ems_env('DB_PORT', '3306');
    $name = ems_env('DB_NAME', 'ems_db');
    $user = ems_env('DB_USER', 'root');
    $pass = ems_env('DB_PASSWORD', '');

    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";

    try {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 5,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        // Log the real error server-side only; never echo it to the browser.
        error_log('[EMS] Database connection failed: ' . $e->getMessage());
        $pdo = null;
        return null;
    }
}

/**
 * Convenience helper: true/false connection check used by the dashboard
 * and health check without needing to run a full query.
 */
function ems_db_is_connected(): bool
{
    return ems_get_connection() instanceof PDO;
}
