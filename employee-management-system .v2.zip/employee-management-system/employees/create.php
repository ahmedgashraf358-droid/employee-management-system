<?php
require_once __DIR__ . '/../includes/functions.php';

$ems_active_nav = 'add';
$errors = [];
$form = ['name' => '', 'email' => '', 'department' => '', 'salary' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form = [
        'name'       => (string)($_POST['name'] ?? ''),
        'email'      => (string)($_POST['email'] ?? ''),
        'department' => (string)($_POST['department'] ?? ''),
        'salary'     => (string)($_POST['salary'] ?? ''),
    ];

    $errors = ems_validate_employee($form);

    if (empty($errors)) {
        if (!ems_db_is_connected()) {
            $errors[] = 'Cannot save: the database is currently unavailable.';
        } elseif (ems_create_employee($form)) {
            ems_set_flash('success', 'Employee "' . $form['name'] . '" was added successfully.');
            header('Location: ' . ems_link('employees/index.php'));
            exit;
        } else {
            $errors[] = 'Failed to save the employee record. Please try again.';
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="ems-page-title">Add Employee</div>
<div class="ems-page-subtitle">Create a new employee record</div>

<div class="ems-panel" style="max-width: 640px;">
  <?php if (!empty($errors)): ?>
    <div class="ems-alert ems-alert-error">
      <?php foreach ($errors as $err): ?>
        <div><?= e($err) ?></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <form method="post" action="<?= ems_link('employees/create.php') ?>">
    <div class="ems-form-row">
      <label for="name">Full Name</label>
      <input type="text" id="name" name="name" class="ems-input" maxlength="100" required value="<?= e($form['name']) ?>">
    </div>
    <div class="ems-form-row">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" class="ems-input" maxlength="150" required value="<?= e($form['email']) ?>">
    </div>
    <div class="ems-form-row">
      <label for="department">Department</label>
      <select id="department" name="department" class="ems-select" required>
        <option value="">Select department...</option>
        <?php foreach (ems_department_options() as $dept): ?>
          <option value="<?= e($dept) ?>" <?= $form['department'] === $dept ? 'selected' : '' ?>><?= e($dept) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="ems-form-row">
      <label for="salary">Salary (USD)</label>
      <input type="number" id="salary" name="salary" class="ems-input" step="0.01" min="0" required value="<?= e($form['salary']) ?>">
    </div>

    <div class="ems-actions" style="margin-top: 18px;">
      <button type="submit" class="ems-btn ems-btn-primary">Save Employee</button>
      <a href="<?= ems_link('employees/index.php') ?>" class="ems-btn">Cancel</a>
    </div>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
