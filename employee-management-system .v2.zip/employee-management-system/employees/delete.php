<?php
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . ems_link('employees/index.php'));
    exit;
}

$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    ems_set_flash('error', 'Invalid employee reference.');
    header('Location: ' . ems_link('employees/index.php'));
    exit;
}

if (!ems_db_is_connected()) {
    ems_set_flash('error', 'Cannot delete: the database is currently unavailable.');
    header('Location: ' . ems_link('employees/index.php'));
    exit;
}

$employee = ems_get_employee($id);

if (!$employee) {
    ems_set_flash('error', 'Employee #' . $id . ' was not found.');
    header('Location: ' . ems_link('employees/index.php'));
    exit;
}

if (ems_delete_employee($id)) {
    ems_set_flash('success', 'Employee #' . $id . ' ("' . $employee['name'] . '") was deleted.');
} else {
    ems_set_flash('error', 'Failed to delete employee #' . $id . '.');
}

header('Location: ' . ems_link('employees/index.php'));
exit;
