<?php
require_once __DIR__ . '/../includes/functions.php';

$ems_active_nav = 'employees';

$search = isset($_GET['search']) ? ems_clean((string)$_GET['search']) : '';
$department = isset($_GET['department']) ? ems_clean((string)$_GET['department']) : '';

$employees = ems_get_employees($search, $department);
$dbOk = ems_db_is_connected();

include __DIR__ . '/../includes/header.php';
?>

<div class="ems-page-title">Employee Directory</div>
<div class="ems-page-subtitle">All employee records &middot; connected to live database</div>

<div class="ems-panel">
  <form class="ems-toolbar" method="get" action="<?= ems_link('employees/index.php') ?>">
    <input
      type="text"
      name="search"
      class="ems-input"
      placeholder="Search by name or email..."
      value="<?= e($search) ?>"
    >
    <select name="department" class="ems-select">
      <option value="">All Departments</option>
      <?php foreach (ems_department_options() as $dept): ?>
        <option value="<?= e($dept) ?>" <?= $department === $dept ? 'selected' : '' ?>><?= e($dept) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="ems-btn">Filter</button>
    <?php if ($search !== '' || $department !== ''): ?>
      <a href="<?= ems_link('employees/index.php') ?>" class="ems-btn">Reset</a>
    <?php endif; ?>
    <a href="<?= ems_link('employees/create.php') ?>" class="ems-btn ems-btn-primary" style="margin-left: auto;">+ Add Employee</a>
  </form>

  <div class="ems-table-wrap">
    <table class="ems-table">
      <thead>
        <tr>
          <th class="mono">ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Department</th>
          <th>Salary</th>
          <th>Created At</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$dbOk): ?>
          <tr class="ems-empty-row">
            <td colspan="7">Database unavailable &mdash; employee records cannot be loaded.</td>
          </tr>
        <?php elseif (empty($employees)): ?>
          <tr class="ems-empty-row">
            <td colspan="7">No employee records match the current filters.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($employees as $emp): ?>
            <tr>
              <td class="mono">#<?= e((string)$emp['id']) ?></td>
              <td><?= e($emp['name']) ?></td>
              <td><?= e($emp['email']) ?></td>
              <td><span class="ems-badge"><?= e($emp['department']) ?></span></td>
              <td class="mono">$<?= e(number_format((float)$emp['salary'], 2)) ?></td>
              <td class="mono"><?= e($emp['created_at']) ?></td>
              <td>
                <div class="ems-actions">
                  <a class="ems-btn ems-btn-sm" href="<?= ems_link('employees/edit.php?id=' . urlencode((string)$emp['id'])) ?>">Edit</a>
                  <form method="post" action="<?= ems_link('employees/delete.php') ?>" onsubmit="return confirm('Delete employee #<?= e((string)$emp['id']) ?>? This cannot be undone.');" style="display:inline;">
                    <input type="hidden" name="id" value="<?= e((string)$emp['id']) ?>">
                    <button type="submit" class="ems-btn ems-btn-sm ems-btn-danger">Delete</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="ems-stat-sub" style="margin-top: 10px;">
    <?= count($employees) ?> record(s) shown<?= ($search !== '' || $department !== '') ? ' (filtered)' : '' ?>.
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
