// EMS // Employee Management System
// Minimal client-side behavior only. All real logic lives server-side in PHP.

document.addEventListener('DOMContentLoaded', function () {
  // Auto-dismiss flash messages after a few seconds.
  var alerts = document.querySelectorAll('.ems-alert');
  alerts.forEach(function (el) {
    setTimeout(function () {
      el.style.transition = 'opacity 0.4s ease';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 400);
    }, 4000);
  });
});
